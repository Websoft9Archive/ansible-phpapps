<?php
$CONFIG = array (
  'instanceid' => 'ocsxfea3dd4z',
  'memcache.locking' => '\\OC\\Memcache\\Redis',
  'memcache.local' => '\\OC\\Memcache\\Redis',
  'redis' =>
      array (
        'host' => 'localhost',
        'port' => 6379,
  ),

);