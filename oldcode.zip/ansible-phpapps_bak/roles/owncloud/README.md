## 如何添加document server?
执行完 OwnCloud 的 ansible 脚本后，再执行 ansible-documentserver 脚本。

## 安装要求
OwnCloud官方对于环境的要求为：https://doc.owncloud.org/server/10.2/admin_manual/installation/system_requirements.html

~~~
Database

MySQL or MariaDB 5.5+

Oracle 11g

PostgreSQL 9 (versions 10 and above are not yet supported)

SQLite

Web server

Apache 2.4 with prefork and mod_php

PHP Runtime

7.0, 7.1, and 7.2
~~~
