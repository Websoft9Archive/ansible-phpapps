Websoft9 Mediawiki Stack 1.32

===========================

1. OVERVIEW

The Websoft9 Project was created to help spread the adoption of freely
available, high quality, open source web applications. Websoft9 aims to make
it easier than ever to discover, install, Use Open Source software

You can learn more about Websoft9 at https://websoft9.com

Websoft9 Mediawiki stack is an easy to install and easy to use open source Web 
Platform. It combines leading open source projects, such as PHP,MYSQL,phpMyAdmin,Apache or Nginx...


2. COMPONENTS and Version

Websoft9 Mediawiki stack ships with the following software versions:

********
- Mediawiki 1.32
— php 7.0.33
- MySQL 5.6.43
- Apache 2.4.6 or Nginx1.14.2
- phpMyAdmin
- Zend OPcache
- Redis 5.0.3

--- PHP Modules ---

Core  date  libxml  openssl  pcre  zlib  filter  hash  Reflection  SPL  session  standard  apache2handler  
bcmath  bz2  calendar  ctype  curl  dom  mbstring  fileinfo  ftp  gd  gettext  gmp  iconv  
imap  intl  json  ldap  exif  mcrypt  mysqlnd  odbc  PDO  Phar  posix  recode  shmop  
SimpleXML  snmp  soap  sockets  sqlite3  sysvmsg  sysvsem  sysvshm  tokenizer  xml  xmlwriter  xsl  mysqli  
pdo_dblib  pdo_mysql  PDO_ODBC  pdo_sqlite  wddx  xmlreader  xmlrpc  igbinary  imagick  zip  redis  Zend OPcache  


********


You can find a quick start guide and more documentation about all of the components at:

中文文档：http://support.websoft9.com/docs/mediawiki-image-guide/
English: https://en.websoft9.com/docs/mediawiki
