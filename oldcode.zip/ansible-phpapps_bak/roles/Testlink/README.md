1. 版本要求: PHP5.6以上（官方推荐 PHP7.2），MySQL5.7以上（MariaDB 10.1.x, Postgres 9.x, MS-SQL 201x 任选其一即可）
2. Supported client web-browsers:
   * Firefox
   * Internet Explorer 9.x or greater
   * Chrome
3. 登录账户和密码: admin/admin
4. MySQL 密码为随机密码，除了 root 账户，还有 testlink 账户。