# NextCloud安装与部署

## 技术要求

官方对安装技术要求：https://docs.nextcloud.com/server/16/admin_manual/installation/system_requirements.html

~~~
php-fpm (recommended)
Ubuntu 18.04 LTS (recommended)
Red Hat Enterprise Linux 7 (recommended)
MySQL or MariaDB 5.5+ (recommended)
PHP7.1,7.2 (recommended),7.3 (recommended)
~~~
