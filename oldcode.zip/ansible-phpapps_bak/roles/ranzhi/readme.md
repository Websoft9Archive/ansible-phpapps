# Ranzhi(Zdoo)

官方安装要求：http://www.zdoo.org/book/zdoomanual/collaborative-tool-source-code-installation-19.html

~~~
PHP >=5.2，activate pdo, pdo_mysql，json, and pcre. Zdoo 4.1+ requires the activation of php_sockets.
MySQL >=4.0
Web server: Apache or Nginx IS recommended
~~~
