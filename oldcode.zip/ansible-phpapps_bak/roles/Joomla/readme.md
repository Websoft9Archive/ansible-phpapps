## joomla安装注意事项
### 环境要求
官方建议php7.1以上，否则报错:https://downloads.joomla.org/technical-requirements
